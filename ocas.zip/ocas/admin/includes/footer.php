 <div class="row">
                        <div class="col-lg-12">
                            <div class="footer">
                                <p>This website is maintained by IT department  </p> 
                            </div>
                        </div>
</div> 