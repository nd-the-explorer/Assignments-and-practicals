<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>

                    <li class="label">Main</li>
                    <li><a href="dashboard.php" ><i class="ti-home"></i>Dashboard</a></li>
                   
                    

                 
                    <li class="label">Apps</li>
                    <li><a class="sidebar-sub-toggle"><i class="ti-user"></i>  Teacher  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                             <li><a href="add-teacher.php">Add Teacher</a>
                    </li>
                            <li><a href="manage-teacher.php">Manage Teacher</a></li>
                           
                        </ul>
                    </li>
                      <li><a href="newsorannouncement.php"><i class="ti-files"></i>Announcement/News</a> 
                    </li>
                    <!-- <li><a class="sidebar-sub-toggle"><i class="ti-user"></i> Uploaded Assignment <span class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                            <li><a href="unchecked-assignment.php">Un Checked</a></li>
                            <li><a href="checked-assignment.php">Checked</a></li>
                        </ul>
                    </li>
                -->
                  <li><a href="bwdates-assign-report.php" ><i class="ti-folder"></i>Reports</a></li>
                  <!-- <li><a href="search.php" ><i class="ti-search"></i>Search</a></li> -->
                </ul>
            </div>
        </div>
    </div>      