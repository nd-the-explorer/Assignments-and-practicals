<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>

                    <li class="label">Main</li>
                    <li><a href="dashboard.php" ><i class="ti-home"></i>Dashboard</a></li>
                                 
                    <li class="label">Apps</li>
                    <li><a class="sidebar-sub-toggle"><i class="ti-folder"></i>  Assignment  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                             <li><a href="new-assignment.php">New Assignment</a>
                    </li>
                            <li><a href="uploaded-assignment.php">Uploaded Assignment</a></li>
                           
                        </ul>
                    </li>
                   
                </ul>
            </div>
        </div>
    </div>