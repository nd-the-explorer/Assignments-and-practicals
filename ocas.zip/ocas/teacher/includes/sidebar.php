<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>
                 
                    <li class="label">Apps</li>

                    
                    

                    <li><a href="dashboard.php" ><i class="ti-home"></i>Dashboard</a></li>

                    <li><a class="sidebar-sub-toggle"><i class="ti-files"></i>  Quiz  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                            <li><a href="add-quiz.php">Create Quiz</a></li>
                            <li><a href="manage-assignment.php">Manage Quiz</a></li>                        </ul>
                    </li>

                    <li><a class="sidebar-sub-toggle"><i class="ti-files"></i>  Assignment  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                             <li><a href="add-assignment.php">Add Assignment</a></li>
                            <li><a href="manage-assignment.php">Manage Assignment</a></li>
                            <li><a href="unchecked-assignment.php">Un Checked</a></li>
                            <li><a href="checked-assignment.php">Checked</a></li>
                        </ul>
                    </li>

                    <li><a class="sidebar-sub-toggle"><i class="ti-files"></i>  Practicals  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                             <li><a href="add-assignment.php">Add Practicals</a></li>
                            <li><a href="manage-assignment.php">Manage Practicals</a></li>
                            <li><a href="unchecked-assignment.php">Un Checked</a></li>
                            <li><a href="checked-assignment.php">Checked</a></li>
                        </ul>
                    </li>

                    <li><a href="subwise-report.php"><i class="ti-files"></i>Reports</a>
                    </li>

                    <li><a href="newsorannouncement.php"><i class="ti-blackboard"></i>Announcement/News</a>
                    </li>
                   
                    <li><a href="reg-coursewiseusers.php"><i class="ti-user"></i>Reg Users</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>